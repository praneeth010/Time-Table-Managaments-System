package entity;

import java.util.List;

public class Department {

	private int Department_id;

	private String Department_name;

	private List<Course> courses;

	private List<Faculty> faculty;

	public Department(String department_name, List<Course> courses, List<Faculty> faculty) {
		super();
		Department_name = department_name;
		this.courses = courses;
		this.faculty = faculty;
	}

	public Department() {
		super();
	}

	public String getDepartment_name() {
		return Department_name;
	}

	public void setDepartment_name(String department_name) {
		Department_name = department_name;
	}

	public List<Course> getCourses() {
		return courses;
	}

	public void setCourses(List<Course> courses) {
		this.courses = courses;
	}

	public List<Faculty> getFaculty() {
		return faculty;
	}

	public void setFaculty(List<Faculty> faculty) {
		this.faculty = faculty;
	}

	@Override
	public String toString() {
		return "Department [Department_id=" + Department_id + ", Department_name=" + Department_name + ", courses="
				+ courses + ", faculty=" + faculty + "]";
	}

}
