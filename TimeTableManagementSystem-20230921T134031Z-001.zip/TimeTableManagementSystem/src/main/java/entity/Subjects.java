package entity;

public class Subjects {
	
	private int subjects_id;
	private String subjects_Name;
	private int NoofPeriodsPerSemester;
	
	private Department department;

	public Subjects() {
		super();
	}

	public Subjects(String subjects_Name, int noofPeriodsPerSemester, Department department) {
		super();
		this.subjects_Name = subjects_Name;
		NoofPeriodsPerSemester = noofPeriodsPerSemester;
		this.department = department;
	}

	public String getSubjects_Name() {
		return subjects_Name;
	}

	public int getNoofPeriodsPerSemester() {
		return NoofPeriodsPerSemester;
	}

	public Department getDepartment() {
		return department;
	}

	public void setSubjects_Name(String subjects_Name) {
		this.subjects_Name = subjects_Name;
	}

	public void setNoofPeriodsPerSemester(int noofPeriodsPerSemester) {
		NoofPeriodsPerSemester = noofPeriodsPerSemester;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}

	@Override
	public String toString() {
		return "Subjects [subjects_Name=" + subjects_Name + ", NoofPeriodsPerSemester=" + NoofPeriodsPerSemester
				+ ", department=" + department + "]";
	}
	
	
}
