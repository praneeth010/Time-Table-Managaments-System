package entity;

public class TimeTable {

}
