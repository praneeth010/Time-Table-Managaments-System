package entityDAO;

import java.sql.Connection;
import java.util.List;

public interface DepartmentDAO {
	
	public void addDepartment(String deptname,Connection con);
	public List<String> getDepartment(Connection con);
	public void deleteDept(Connection con, String deptId);
}
