package entityDAO;

import java.sql.Connection;
import java.util.List;

import entity.Faculty;

public interface FacultyDAO {
	public List<List<Object>> algoritham(Connection con,String deptName);

	public void addfaculty(Connection con,String dept, String facultyname);

	public void deletefaculty(Connection con, int facultyId);

	
	

}
