

package entityDAO;

import java.sql.Connection;
import java.util.List;
import java.util.Map;

public interface GeneratorDAO {
	
	public  Map<String,List<Object>> algoritham(Connection con,String deptName,String courseName,String semId,String sectionId, int week, int day, int period, List<String> dayList, List<String> perList);
	
}
