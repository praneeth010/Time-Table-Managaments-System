package entityDAO;

import java.sql.Connection;
import java.util.List;

public interface ListDAO {
	
	public List<String> deptList(Connection con);
	public List<String> courList(Connection con);
	public List<String> subList(Connection con);
	public List<String> facList(Connection con);
	public List<String> semList(Connection con);
	public List<String> secList(Connection con);
	public List<String> dayList(Connection con);
	public List<String> perList(Connection con);

}
