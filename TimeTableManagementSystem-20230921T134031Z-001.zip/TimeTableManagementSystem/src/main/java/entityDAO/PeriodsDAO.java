package entityDAO;

import java.sql.Connection;
import java.sql.Time;
import java.time.Period;
import java.util.List;

public interface PeriodsDAO {
		
	public void addPeriod(String periodName,String periodfrom,String periodTo ,Connection con);
	public List<String> getPeriod(Connection con);
	public void updatePeriod( String periodName, String periodFrom, String periodTo, Connection con);
	public void deletePeriod(Connection con, String periodId);

	
}
