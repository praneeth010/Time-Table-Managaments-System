package entityDAO;

public interface SectionsDAO {

}
