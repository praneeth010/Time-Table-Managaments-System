package entityDAO;

public interface SemesterDAO {

}
