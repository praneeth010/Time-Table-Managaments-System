package entityDAO;

import java.sql.Connection;
import java.util.List;

public interface SubFacDAO {
	public List<List<Object>> algoritham(Connection con,String deptName,String courseName,String semId,String sectionId);
	public void addSubFac(Connection con,String deptName,String courseName,String semId,String sectionId, String sub, String fac);
	public void deleteSubFac(Connection con, int SubFacId);
}
