package entityDAO;

import java.sql.Connection;
import java.util.List;

public interface SubjectsDAO {

	public List<List<Object>> algoritham(Connection con,String deptName,String courseName,String semId);
	
	
	public void addSubjects(Connection con, String deptName, String courseName, String semId, String sub);

	public void deleteSubject(Connection con, int subId);
	
	public void editSubject(Connection con, int subId,String SubjectName);
	
}