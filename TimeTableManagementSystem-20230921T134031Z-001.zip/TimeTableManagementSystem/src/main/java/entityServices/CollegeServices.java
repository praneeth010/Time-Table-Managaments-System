package entityServices;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import entity.College;
import entityDAO.CollegeDAO;

public class CollegeServices implements CollegeDAO{
	
	@Override
	public void addCollege(String college_name, Connection con) {
		try {
			String query = "INSERT INTO college (college_name) VALUES (?)";
		 PreparedStatement st = con.prepareStatement(query);
			st.setString(1, college_name);
			 st.executeUpdate();
		}catch (SQLException e) {
			System.out.println("unable to connect with database");
		}
	}
	
    @Override
	public List<String> getCollege(Connection con) {
    	 List<String> collegeList = new ArrayList<>();
		try {
			String query = "SELECT college_name FROM college";
		 PreparedStatement st = con.prepareStatement(query);
		 ResultSet rs = st.executeQuery();
		 while (rs.next()) {
			 String s=rs.getString("college_name");
	            collegeList.add(s);
	        }
	    } catch (SQLException e) {
	        
	        e.printStackTrace();
	    }
	    return collegeList;
	}
	@Override
	public void deleteCollege(Connection con, String collegeId) {
		try {
			String query = "DELETE FROM college WHERE college_name = ?";
		 PreparedStatement st = con.prepareStatement(query);
			st.setString(1, collegeId);
			 st.executeUpdate();
		}catch (SQLException e) {
			System.out.println("unable to connect with database");
		}
		
	}


}


