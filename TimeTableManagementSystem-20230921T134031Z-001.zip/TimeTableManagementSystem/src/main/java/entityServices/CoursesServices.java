package entityServices;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import entityDAO.CoursesDAO;

public class CoursesServices implements CoursesDAO {
	List<List<Object>> assign = new ArrayList<>();
	@Override
	public List<List<Object>> algoritham(Connection con, String deptName) {
		try {

			String query = "SELECT * FROM course WHERE deptId=?";
			PreparedStatement st = con.prepareStatement(query);
			st.setString(1, deptName);
			ResultSet rs = st.executeQuery();
			while (rs.next()) {
				int i = rs.getInt("courseId");
				String s = rs.getString("courseName");
				String f = rs.getString("deptId");
				List<Object> entry = Arrays.asList(f, s, i);
				assign.add(entry);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return assign;
	}

	@Override
	public void addCourse(Connection con,String dept, String coursename) {
		try {
			String query = "INSERT INTO course (courseName, deptId) VALUES (?, ?)";
			PreparedStatement st = con.prepareStatement(query);
			st.setString(1, coursename);
			st.setString(2, dept);
			st.executeUpdate();
			st.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
		

	@Override
	public void deletecourses(Connection con, int courseId) {
		try {
			String query = "DELETE FROM course WHERE courseId = ?";
		 PreparedStatement st = con.prepareStatement(query);
			st.setInt(1, courseId);
			 st.executeUpdate();
		}catch (SQLException e) {
			System.out.println("unable to connect with database");
		}
		
	}
	
	}
