package entityServices;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import entityDAO.CoursesDAO;
import entityDAO.DepartmentDAO;

public class DepartmentServices implements DepartmentDAO{

	@Override
	public void addDepartment(String deptname, Connection con) {
		try {
			int collegeId = 1001;
			String query = "INSERT INTO department (deptname, collegeId) VALUES (?, ?)";
            PreparedStatement st = con.prepareStatement(query);
			st.setString(1, deptname);
			st.setInt(2, collegeId);
			 st.executeUpdate();
		}catch (SQLException e) {
			System.out.println("unable to connect with database");
		}
	}
		

	@Override
	public List<String> getDepartment(Connection con) {
		List<String> collegeList = new ArrayList<>();
		try {
			String query = "SELECT deptname FROM department";
		 PreparedStatement st = con.prepareStatement(query);
		 ResultSet rs = st.executeQuery();
		 while (rs.next()) {
			 String s=rs.getString("deptname");
	            collegeList.add(s);
	        }
	    } catch (SQLException e) {
	        
	        e.printStackTrace();
	    }
	    return collegeList;
	}


	@Override
	public void deleteDept(Connection con, String deptId) {
		try {
			String query = "DELETE FROM department WHERE deptname = ?";
		 PreparedStatement st = con.prepareStatement(query);
			st.setString(1, deptId);
			 st.executeUpdate();
		}catch (SQLException e) {
			System.out.println("unable to connect with database");
		}
		
	}

}
