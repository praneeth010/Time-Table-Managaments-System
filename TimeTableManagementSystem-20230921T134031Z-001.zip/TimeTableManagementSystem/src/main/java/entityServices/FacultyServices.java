package entityServices;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import entity.Faculty;
import entityDAO.FacultyDAO;

public class FacultyServices implements FacultyDAO {
	List<List<Object>> assign = new ArrayList<>();
	@Override
	public List<List<Object>> algoritham(Connection con, String deptName) {
		try {

			String query = "SELECT * FROM faculty WHERE departmentid=?";
			PreparedStatement st = con.prepareStatement(query);
			st.setString(1, deptName);
			ResultSet rs = st.executeQuery();
			while (rs.next()) {
				String s = rs.getString("facultyname");
				String f = rs.getString("departmentid");
				int i = rs.getInt("facultyid");
				List<Object> entry = Arrays.asList(f, s, i);
				assign.add(entry);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return assign;
	}

	@Override
	public void addfaculty(Connection con,String dept, String facultyname) {
		try {
			String query = "INSERT INTO faculty(facultyname, departmentid) VALUES (?, ?)";
			PreparedStatement st = con.prepareStatement(query);
			st.setString(1, facultyname);
			st.setString(2, dept);
			st.executeUpdate();
			st.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
		

	@Override
	public void deletefaculty(Connection con, int facultyid) {
		try {
			String query = "DELETE FROM faculty WHERE facultyid=?";
			PreparedStatement st = con.prepareStatement(query);
			st.setInt(1, facultyid);
			st.executeUpdate();
		}catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	
	}