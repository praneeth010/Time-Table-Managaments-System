package entityServices;

import entityDAO.CoursesDAO;
import entityDAO.SectionsDAO;

public class SectionServices implements SectionsDAO{

}
