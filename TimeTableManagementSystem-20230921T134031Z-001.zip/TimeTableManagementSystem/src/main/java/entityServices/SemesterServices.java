package entityServices;

import entityDAO.CoursesDAO;
import entityDAO.SemesterDAO;

public class SemesterServices implements SemesterDAO{

}
