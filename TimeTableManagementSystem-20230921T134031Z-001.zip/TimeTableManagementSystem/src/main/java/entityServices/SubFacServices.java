package entityServices;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import entityDAO.SubFacDAO;

public class SubFacServices implements SubFacDAO {
	Map<String, String> subjectFacultyMap = new HashMap<>();
	List<List<Object>> assign = new ArrayList<>();
	@Override
	public List<List<Object>> algoritham(Connection con, String deptName, String courseName, String semId,
			String sectionId) {
		try {

			String query = "SELECT * FROM subfacalot WHERE deptName=? AND courseName=? AND semId=? AND sectionId=?";
			PreparedStatement st = con.prepareStatement(query);
			st.setString(1, deptName);
			st.setString(2, courseName);
			st.setString(3, semId);
			st.setString(4, sectionId);
			ResultSet rs = st.executeQuery();
			while (rs.next()) {
				int i = rs.getInt("sno");
				String s = rs.getString("subjectName");
				String f = rs.getString("facultyname");
				List<Object> entry = Arrays.asList(i, s, f);
				assign.add(entry);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return assign;
	}

	@Override
	public void addSubFac(Connection con, String deptName, String courseName, String semId, String sectionId,
			String sub, String fac) {
		try {
			String query = "INSERT INTO subfacalot (deptName, courseName, semId, sectionId, subjectName, facultyName) VALUES (?, ?, ?, ?, ?, ?)";
			PreparedStatement st = con.prepareStatement(query);
			st.setString(1, deptName);
			st.setString(2, courseName);
			st.setString(3, semId);
			st.setString(4, sectionId);
			st.setString(5, sub);
			st.setString(6, fac);
			st.executeUpdate();
			st.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void deleteSubFac(Connection con, int SubFacId) {
		try {
			String query = "DELETE FROM subfacalot WHERE sno = ?";
		 PreparedStatement st = con.prepareStatement(query);
			st.setInt(1, SubFacId);
			 st.executeUpdate();
		}catch (SQLException e) {
			System.out.println("unable to connect with database");
		}
		
	}

}
