package entityServices;

import entityDAO.CoursesDAO;
import entityDAO.TimeTableDAO;

public class TimeTableServices implements TimeTableDAO{

}
