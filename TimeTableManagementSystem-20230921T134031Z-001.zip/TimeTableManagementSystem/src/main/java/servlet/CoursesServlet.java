package servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import entityDAO.ListDAO;
import entityDAO.CoursesDAO;
import entityServices.ConnectionServices;
import entityServices.CoursesServices;
import entityServices.ListServices;

@WebServlet("/CoursesServlet")
public class CoursesServlet extends HttpServlet {
	ListDAO cr = new ListServices();
	CoursesDAO g = new CoursesServices();
	Connection con;
	List<List<Object>> cour;
	String dept;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");

		ConnectionServices c = new ConnectionServices();
		con = c.Con();
		List<String> deptList = cr.deptList(con);
		request.setAttribute("deptList", deptList);
		request.getRequestDispatcher("course.jsp").forward(request, response);

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		List<String> deptList = cr.deptList(con);
		request.setAttribute("deptList", deptList);
		dept = request.getParameter("dept");
		cour = g.algoritham(con, dept);
		request.setAttribute("courList", cour);
		request.getRequestDispatcher("course.jsp").forward(request, response);
		cour.clear();
	}

}
