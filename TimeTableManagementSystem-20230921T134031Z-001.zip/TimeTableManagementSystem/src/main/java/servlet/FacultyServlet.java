package servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import entity.Faculty;
import entityDAO.CoursesDAO;
import entityDAO.FacultyDAO;
import entityDAO.ListDAO;
import entityServices.ConnectionServices;
import entityServices.CoursesServices;
import entityServices.FacultyServices;
import entityServices.ListServices;

@WebServlet("/FacultyServlet")
public class FacultyServlet extends HttpServlet {
	ListDAO cr = new ListServices();
	FacultyDAO g = new FacultyServices();
	Connection con;
	List<List<Object>> fact;
	String dept;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");

		ConnectionServices c = new ConnectionServices();
		con = c.Con();
		String method = request.getParameter("method");
		if ("doDelete".equals(method)) {
			doDelete(request, response);
		}
		List<String> deptList = cr.deptList(con);
		request.removeAttribute("facList");
		request.setAttribute("deptList", deptList);
		request.getRequestDispatcher("faculty.jsp").forward(request, response);

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		List<String> deptList = cr.deptList(con);
		request.setAttribute("deptList", deptList);
		dept = request.getParameter("dept");
		fact = g.algoritham(con, dept);
		request.setAttribute("facList", fact);
		request.getRequestDispatcher("faculty.jsp").forward(request, response);
		fact.clear();
	}

	protected void doDelete(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int facultyid = Integer.parseInt(request.getParameter("id"));
		g.deletefaculty(con, facultyid);

	}

}
