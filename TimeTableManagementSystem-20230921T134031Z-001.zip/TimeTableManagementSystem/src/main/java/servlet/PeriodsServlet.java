package servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import entityDAO.PeriodsDAO;
import entityServices.ConnectionServices;
import entityServices.PeriodsServices;


@WebServlet("/PeriodsServlet")
public class PeriodsServlet extends HttpServlet {
	PeriodsDAO pd=new PeriodsServices();
	Connection con;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		ConnectionServices c = new ConnectionServices();
		con = c.Con();
		String periodId = request.getParameter("periodId");
		pd.deletePeriod(con,periodId );
		List<String> periodList = pd.getPeriod(con);
		request.setAttribute("periodname", periodList);	
		request.setAttribute("periodfrom", periodList);		
		request.setAttribute("periodto", periodList);		

		
		  request.getRequestDispatcher("periods.jsp").forward(request, response);
	
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String periodname = request.getParameter("name");
		String periodfrom = request.getParameter("from");
		String periodto = request.getParameter("to");
		pd.addPeriod(periodname, periodfrom, periodto, con);
	}
	protected void doPut(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    String periodName = request.getParameter("name");
	    String periodFrom = request.getParameter("from");
	    String periodTo = request.getParameter("to");
	    pd.updatePeriod( periodName, periodFrom, periodTo, con);

	    response.sendRedirect("periods.jsp");
	}
}