package servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import entityDAO.GeneratorDAO;
import entityDAO.ListDAO;
import entityDAO.SubFacDAO;
import entityServices.ConnectionServices;
import entityServices.GeneratorServices;
import entityServices.ListServices;
import entityServices.SubFacServices;

@WebServlet("/SubFacadServlet")
public class SubFacadServlet extends HttpServlet {
	SubFacDAO g = new SubFacServices();
	ListDAO cr = new ListServices();
	List<List<String>> sub;
	
	Connection con;
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");

		ConnectionServices c = new ConnectionServices();
		con = c.Con();
		List<String> deptList = cr.deptList(con);
        List<String> courList = cr.courList(con);
        List<String> semList = cr.semList(con);
        List<String> secList = cr.secList(con);
        List<String> facList = cr.facList(con);
        List<String> subList = cr.subList(con);
        
        request.setAttribute("deptList", deptList);
        request.setAttribute("courList", courList);
        request.setAttribute("semList", semList);
        request.setAttribute("secList", secList);
        request.setAttribute("facList", facList);
        request.setAttribute("subList", subList);
        request.getRequestDispatcher("subfacad.jsp").forward(request, response);

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
        
		String dept = request.getParameter("dept1");
		String cour = request.getParameter("cour1");
		String sem = request.getParameter("sem1");
		String sec = request.getParameter("sec1");
		String sub = request.getParameter("sub1");
		String fac = request.getParameter("fac1");
		g.addSubFac(con, dept, cour, sem, sec, sub, fac);
		
	}
}
