package servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import entityDAO.CoursesDAO;
import entityDAO.DepartmentDAO;
import entityDAO.ListDAO;
import entityDAO.SemesterDAO;
import entityDAO.SubjectsDAO;
import entityServices.ConnectionServices;
import entityServices.CoursesServices;
import entityServices.DepartmentServices;
import entityServices.ListServices;
import entityServices.SemesterServices;
import entityServices.SubjectsServices;

@WebServlet("/SubjectServlet")
public class SubjectServlet extends HttpServlet {
	SubjectsDAO g = new SubjectsServices();
	ListDAO cr = new ListServices();
	List<List<Object>> sub;
	
	Connection con;
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");

		ConnectionServices c = new ConnectionServices();
		con = c.Con();
		String method = request.getParameter("method");
		if("doDelete".equals(method)) {
			doDelete(request,response);
		}
		String method1 = request.getParameter("method");
		if("doPut".equals(method1)) {
			doPut(request,response);
		}
		List<String> deptList = cr.deptList(con);
		List<String> courList = cr.courList(con);
		List<String> semList = cr.semList(con);
		
		 request.setAttribute("deptList", deptList);
		 request.setAttribute("courList", courList);
		 request.setAttribute("semList", semList);
 
        request.getRequestDispatcher("subjects.jsp").forward(request, response);

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		List<String> deptList = cr.deptList(con);
		List<String> courList = cr.courList(con);
		List<String> semList = cr.semList(con);
		
		String dept = request.getParameter("dept1");
        String cour = request.getParameter("cour1");
        String sem = request.getParameter("sem1");
		sub=g.algoritham(con, dept, cour, sem);
		request.setAttribute("subList", sub);
        request.setAttribute("deptList", deptList);
        request.setAttribute("courList", courList);
        request.setAttribute("semList", semList);

		request.getRequestDispatcher("subjects.jsp").forward(request, response);
		sub.clear();
	}
	
	protected void doDelete(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int SubId = Integer.parseInt(request.getParameter("id"));
		g.deleteSubject(con, SubId);
	}
	
	protected void doPut(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		

	}
}