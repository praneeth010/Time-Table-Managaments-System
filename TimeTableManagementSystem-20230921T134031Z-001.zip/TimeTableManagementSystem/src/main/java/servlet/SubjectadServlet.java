package servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import entityDAO.DepartmentDAO;
import entityDAO.ListDAO;
import entityDAO.SubjectsDAO;
import entityServices.ConnectionServices;
import entityServices.DepartmentServices;
import entityServices.ListServices;
import entityServices.SubjectsServices;


@WebServlet("/SubjectadServlet")
public class SubjectadServlet extends HttpServlet {
	DepartmentDAO de=new DepartmentServices();
	SubjectsDAO g = new SubjectsServices();
	ListDAO cr = new ListServices();
	List<List<String>> sub;
	
	Connection con;
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");

		ConnectionServices c = new ConnectionServices();
		con = c.Con();
		List<String> deptList = cr.deptList(con);
        List<String> courList = cr.courList(con);
        List<String> semList = cr.semList(con);
  
        request.setAttribute("deptList", deptList);
        request.setAttribute("courList", courList);
        request.setAttribute("semList", semList);
        request.getRequestDispatcher("subjectsad.jsp").forward(request, response);

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String sub = request.getParameter("sub");
		String dept = request.getParameter("dept");
		String cour = request.getParameter("cour");
		String sem = request.getParameter("sem");
		g.addSubjects(con,dept, cour, sem, sub);
		
	}
}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	